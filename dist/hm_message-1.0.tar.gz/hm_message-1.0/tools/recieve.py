def recieve_msg():
    print("recieve msg from 100XX")