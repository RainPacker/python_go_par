def send_msg():
    print("send msg XX ")